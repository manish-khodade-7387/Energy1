<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Report Download Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>New Report Download Request</h1>
    <p>A new report download request has been submitted. Details are as follows:</p>
    <table>
        <tr>
            <th>Report Title</th>
            <td><?= esc($contact_rep_title) ?></td>
        </tr>
        <tr>
            <th>Report Date</th>
            <td><?= esc($contact_rep_date) ?></td>
        </tr>
        <tr>
            <th>Contact Person</th>
            <td><?= esc($contact_person) ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?= esc($contact_email) ?></td>
        </tr>
        <tr>
            <th>Phone</th>
            <td><?= esc($contact_phone) ?></td>
        </tr>
        <tr>
            <th>Company</th>
            <td><?= esc($contact_company) ?></td>
        </tr>
        <tr>
            <th>Job Role</th>
            <td><?= esc($contact_job_role) ?></td>
        </tr>
        <tr>
            <th>Report URL</th>
            <td><?= esc($contact_report_url) ?></td>
        </tr>
        <tr>
            <th>Contact Code</th>
            <td><?= esc($contact_code) ?></td>
        </tr>
        <tr>
            <th>Date and Time</th>
            <td><?= esc($contact_datetime) ?></td>
        </tr>
    </table>
</body>
</html>
