<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Page</title>
    <!-- Include CSS files -->
    <!-- Make sure to include the necessary CSS files here -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/category.css">

    <style>
        .linktag {
            font-size: 17px !important;
            padding: 10px 10px 4px 80px !important;
            background-color: #e3b04b !important;
        }
    </style>
</head>

<body>
    <!-- Include header.php -->
    <?php include('header.php'); ?>

    <div class="col-md-12">
        <ol class="breadcrumb linktag">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
            <li class="breadcrumb-item active">Search Results</li>
        </ol>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <div class="head-2">
                    <h1 class="title">Search<span> Reports</span></h1>
                </div>
            </div>

            <!-- Search results section -->
            <div class="col-md-12" id="search_results">
                <!-- Search results will be displayed here -->
            </div>
        </div>
    </div>


    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initial page load
            var searchTerm = '';
            if (sessionStorage.getItem('searchTerm')) {
                searchTerm = sessionStorage.getItem('searchTerm');
                $('#search_term').val(searchTerm);
                loadReports(1);
            }

            // Function to load reports via AJAX
            function loadReports(page) {
                searchTerm = $('#search_term').val().trim(); // Get search term
                sessionStorage.setItem('searchTerm', searchTerm);
                // Update URL with the search term
                var newUrl = window.location.pathname + '?s=' + searchTerm;
                window.history.pushState({
                    path: newUrl
                }, '', newUrl);

                $.ajax({
                    url: '<?= base_url('search/paginate') ?>', // URL to your controller method for pagination
                    type: 'GET',
                    data: {
                        s: searchTerm,
                        page: page
                    }, // Send search term and page number to the server
                    dataType: 'json',
                    success: function(response) {
                        // Clear previous search results
                        $('#search_results').empty();

                        if (response.searchResults.length === 0) {
                            var noResultsHtml = `
                                <div class="col-md-8">
                                    <div class="alert alert-warning">NO Result Found. &nbsp; Search Your Report Here!</div>
                                   
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            <h5>YOUR CONTACT INFORMATION</h5>
                                        </div>
                                        <!-- Display error messages -->
                                        <?php if (session()->has('error')) : ?>
                                            <div class="alert alert-danger" role="alert">
                                                <?= session()->get('error') ?>
                                             </div>
                                        <?php endif; ?>
                                        <div class="panel-body">
                                            <form name="form" id="searchForm" action="<?= base_url('store-search-data') ?>" method="post" class="cust-form form-horizontal col-sm-12 bv-form">
                                                <input type="hidden" name="csrf_chem_name" value="424de960f151ca7493d6587a7be51c06">
                                                <p class="title">Please fill following form for more information.</p>
                                                <div class="form-group has-feedback">
                                                    <label class="control-label col-sm-4" for="topic">Search Keywords *:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" id="topic" name="topic" placeholder="Enter your Reports" required>
                                                    </div>
                                                </div>
                                                <div class="form-group has-feedback">
                                                    <label class="control-label col-sm-4" for="full_name">Full Name *:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Your Full Name" required>
                                                    </div>
                                                </div>
                                                <div class="form-group has-feedback">
                                                    <label class="control-label col-sm-4" for="email_id">Business E-mail *:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" id="email_id" name="email_id" placeholder="Enter Your E-mail Id" required   required style="text-transform: lowercase;">
                                                    </div>
                                                </div>
                                                <div class="form-group has-feedback">
                                                    <label class="control-label col-sm-4" for="message12">Message:</label>
                                                    <div class="col-sm-8">
                                                        <textarea type="text" class="form-control inputtextarea" id="message12" name="message" placeholder="Enter Your Message" required></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 form-group">
                                                    <div class="sec-code">
                                                        <label for="question">Security Code*</label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-8 form-group has-feedback">
                                                    <div class="col-sm-10">
                                                        <div class="input-group refresh-captcha">
                                                            <span class="input-group-addon" id="captcha">
                                                                <span id="security_code" style="font-weight: 500;"><?= $securityCode ?></span>
                                                            </span>
                                                            <input type="text" name="captcha_code" class="form-control captchacode" placeholder="Enter Security Code" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 form-group btn-sub">
                                                        <button class="btn-sub1" type="submit">Submit <i class="fa fa-paper-plane"></i></button>
                                                    </div>
                                                </div>
                                                <input type="hidden" value="">
                                            </form>
                                        </div>
                                    </div>
                                </div>`;
                            $('#search_results').append(noResultsHtml);
                        } else {
                            // Iterate over the response and append search results to the container
                            $.each(response.searchResults, function(index, result) {
                                var html = `
                                    <div class="col-md-12 report-list searchList latest">
                                        <p class="date">${result.rep_date}</p>
                                        <img alt="" class="report-cover" src="<?= base_url() ?>./assets/images/Speciality-Chemical.jpg" title="report tile">
                                        <h4><a href="#">${result.rep_title}</a></h4>
                                        <p>Pages: ${result.rep_page} &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; Report Code: ${result.rep_id} &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                                        <a href="<?= base_url() ?>/report/${result.rep_id}/${encodeURIComponent(result.rep_url)}"><strong class="read">Read more</strong></a></p>
                                    </div>`;
                                $('#search_results').append(html);
                            });
                            $('#search_results').css({
                                'display': 'contents'
                            });
                            // Generate pagination
                            generatePagination(page, response.totalItems, response.itemsPerPage);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            }

            // Pagination click event
            $(document).on('click', '.pagination a', function(e) {
                e.preventDefault();
                var page = $(this).attr('data-ci-pagination-page');
                loadReports(page);
            });

            // Search form submit event
            $('#searchForm').submit(function(e) {
                e.preventDefault();
                loadReports(1);
            });


        });
    </script>

    <!-- Include the footer -->
    <?php include('footer.php'); ?>
</body>

</html>