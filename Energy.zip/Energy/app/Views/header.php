


<!--<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">-->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css">

</head>
<style>



.top-bd-new {
    background-image: linear-gradient(319deg, #ba2d0b -52%, #fe7f2d 37%, #ffbf46 80%) !important;

}

.new-navigation nav a {
    font-weight: 500 !important;}



	.new-navigation {
		line-height: 45px !important;

	}

	a {
		text-decoration: none;
	}

	@media only screen and (min-width: 720px)and (max-width:920px) {
		.rd-tab {
			display: flex;
		}

		.search_box {
			width: 350px;
		}

		.link_follow ul li a {
			width: 30px;
			height: 30px;
			line-height: 30px;
			font-size: 15px;
		}

		.call_text h3 {
			font-size: 20px;
		}

		.discover_now a {
			text-align: center;
			font-size: 12px;
			width: 120px;
			padding: 0px;
		}
	}
</style>

<body>


	<div class="top-bd-new">
		<div class="container">
			<div class="row">

				<div class="col-md-12 col-xs-12 top_inner">
					<div class="follow_us">
						<label>Follow Us:</label>
						<ul class="follow_link">
							<li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-x-twitter"></i></i></a></li>
							<li><a href="#"><i class="fa-brands fa-google"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
						</ul>
					</div>
					<div class="top_links">
						<ul>
							<li><a href="#"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;My Account</a></li>
							<li><a href="#"><i class="fa fa-flag" aria-hidden="true"></i>&nbsp;&nbsp;en-gb</a></li>
							<li>$&nbsp;&nbsp;USD</a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-12 col-xs-12 navigation">
					<div class="row">
						<div class="col-lg-3 col-md-3">
							<a href="<?= base_url() ?>" class="logo">
								<img src="<?= base_url() ?>assets/images/logo-new.png" alt="24chemical logo" title="24Chemical Research"></a>
						</div>

						<div class="col-lg-9 col-md-9">
							<div class="middel_right">
								<div class="search-container">
									<form id="searchForm" action="<?= base_url('search-result') ?>" method="get">
										<div class="search_box">
											<input type="text" id="search_term" name="s" placeholder="Search market report ...">
											<button type="submit"><i class="fa fa-search"></i></button>
										</div>
									</form>
								</div>
								<div class="middel_right_info">
									<div class="mini_cart_wrapper">
										<a href="<?= base_url() ?>cart">
											<i class="fa fa-shopping-cart" aria-hidden="true"></i>
											Cart item
										</a>
										<span class="cart_quantity"><?= esc($reportCount) ?></span>
									</div>
								</div>
							</div>
						</div>



					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="new-navigation">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav>
						<a href="<?= base_url() ?>" class="active">HOME</a>
						<a href="<?= base_url() ?>about-Us">ABOUT US</a>
						<a href="<?= base_url() ?>letest-reports">LATEST REPORTS</a>
						<a href="<?= base_url() ?>categories">REPORTS CATEGORY</a>
						<a href="<?= base_url() ?>blog">BLOG</a>
						<a href="<?= base_url() ?>contact-us">CONTACT US</a>
					</nav>
				</div>
			</div>
		</div>
	</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	 -->
	<!-- Latest compiled JavaScript -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>






</body>

</html>