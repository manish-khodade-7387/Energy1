<?php
/** @var array $formData */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank you for contacting us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            margin-bottom: 20px;
        }
        .message {
            background-color: #f9f9f9;
            padding: 15px;
            border-left: 4px solid #007bff;
            margin-bottom: 20px;
            white-space: pre-wrap;
        }
        .footer {
            text-align: center;
            color: #777;
            font-size: 12px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank you for contacting us</h1>
        <p>Dear <?= esc($formData['Username']) ?>,</p>
        <p>Thank you for contacting us. We have received your message and will get back to you shortly.</p>
        <p><strong>Your message:</strong></p>
        <div class="message"><?= esc($formData['Message']) ?></div>
        <p>Best regards,<br>24 Web Tech</p>
        <p class="footer">This email was automatically generated. Please do not reply to this email.</p>
    </div>
</body>
</html>
