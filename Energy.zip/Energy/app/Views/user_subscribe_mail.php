<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Subscription Confirmation</title>
</head>
<body>
    <h2>Thank you for Subscribing!</h2>
    <p>You have successfully subscribed to our newsletter. You will receive updates and special offers via email.</p>
    <p>Thank you.</p>
</body>
</html>
