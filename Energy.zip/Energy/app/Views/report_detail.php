<!DOCTYPE html>
<html lang="en">

<head>
	<title>Report Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/new.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css">


<style>
   .trim-line{
	overflow: hidden;
text-overflow: ellipsis;
display: -webkit-box;
-webkit-line-clamp: 3;
-webkit-box-orient: vertical;
   }


</style>

	<!-- Include header.php -->
	<?php include('header.php'); ?>

	<div class="col-md-12">
	<ol class="breadcrumb linktag">
		<li class="breadcrumb-item"><a href="<?=base_url()?>">Home</a></li>
		<li class="breadcrumb-item active"><?= $report['rep_title']; ?></li>
	</ol>
	</div>


	<div class="container">
		<div class="row">

			<!-- display report detsils like title start -->
			<div class="col-md-12">
				<div class="rd-detils">
					<div class="rd-cover">
						<img src="https://www.24marketreports.com/assets/images/covers/manufacturing-and-construction/Manufacturing-and-Construction2.jpg" alt="Southeast  Methyl Cinnamic Aldehyde Market" itemprop="image">
					</div>
					<div class="rd-container">
						<h1><?= $report['rep_title']; ?></h1>
						<ul class="rd-list">
							<li><?= esc($category['sc1_name']); ?></li>
							<li><?= $report['rep_date']; ?></li>
							<li><?= $report['rep_page']; ?> Pages</li>

							<li>Formats:
								<i class="fa fa-file-pdf-o" title="PDF Format">&nbsp;</i>
								<i class="fa fa-file-excel-o" title="Excel Format">&nbsp;</i>
								<i class="glyphicon glyphicon-cd" title="CD Format"></i>
							</li>
							<li>Report Code: <?= $report['rep_id']; ?></li>
						</ul>
					</div>

					<div class="sample-top">
						<span class=" download-span">Download FREE Report Sample:</span>
						<a href="<?= base_url('download-sample/' . $report['rep_id'] . '/' . urlencode($report['rep_url'])) ?>" rel="nofollow">
						    <i class="fa fa-download"></i> Download Sample Report PDF</a>
						
					</div>

				</div>

				
			</div>
			
			<!-- display report detsils like title start -->


			<!--  display overview , toc , lot/lif  -->
			<div class="col-md-8">

				<ul class="nav nav-tabs nav-justified rd-tab" id="pills-tab">
					<li class="nav-item" role="presentation">
						<button class="nav-link active" id="pills-overview-tab" data-bs-toggle="pill" data-bs-target="#pills-overview" type="button" role="tab" aria-controls="pills-overview" aria-selected="true">OverView</button>
					</li>
					<li class="nav-item" role="presentation">
						<button class="nav-link" id="pills-toc-tab" data-bs-toggle="pill" data-bs-target="#pills-toc" type="button" role="tab" aria-controls="pills-toc" aria-selected="false">Table Of Content</button>
					</li>
					<li class="nav-item" role="presentation">
						<button class="nav-link" id="pills-figures-tab" data-bs-toggle="pill" data-bs-target="#pills-figures" type="button" role="tab" aria-controls="pills-figures" aria-selected="false">List of Table / Figures</button>
					</li>
				</ul>







				<!-- fetch  details data in this div start -->
				<div class="tab-content cust-tabp">
					<div class="tab-pane fade show active" id="pills-overview">

						<?= $reportDetail['rep_contents']; ?>

						<div class="clearfix"></div>
					</div>
					<div class="tab-pane fade" id="pills-toc"> <?php
																// Assuming $reportDetail['rep_table_of_contents'] contains the table of contents data
																$toc_content = $reportDetail['rep_table_of_contents'];

																// Split the content by newline character
																$toc_items = explode("\n", $toc_content);

																// Loop through each item and add spaces
																foreach ($toc_items as $item) {
																	echo $item . "<br>"; // Add a space or any other separator you prefer between items
																}
																?></div>




					<div class="tab-pane fade" id="pills-figures">
						<?php
						// Assuming $reportDetail['rep_table_text'] contains the list of tables/figures data
						$figures_content = $reportDetail['rep_table_text'];

						// Split the content by newline character
						$figures_list = explode("\n", $figures_content);

						// Loop through each item and add spaces
						foreach ($figures_list as $figure) {
							echo $figure . "<br>"; // Add a space or any other separator you prefer between items
						}
						?>
					</div>
				</div>





				<!-- Display Tag -->
				<div class="rd-tags">
					<strong>Tags : </strong><a href="#">dsohfsd sdf</a>
				</div>

				<!-- fetch  details data in this div End -->


			</div>





			<!-- disply report Licenses start AND CART -->


			<div class="col-md-4">

				<div class="purhs-box">



				<form action="<?= base_url('cart/add') ?>" method="post">

						<div class="puchs-head">CHOOSE YOUR BUYING OPTION</div>

						<div class="puchs-body">
							<div class="puchs-barow">

								<?php foreach ($reportLicenses as $license) : ?>
									<label class="cust-radio">
										<input name="report_license" type="radio" value="<?php echo htmlspecialchars($license['li_key'] . '-' . $license['li_value']); ?>" <?php if ($license === reset($reportLicenses)) echo 'checked'; ?>>
										<div class="active">
											<i></i>
											<?php echo htmlspecialchars($license['li_key']); ?>:<span>$<?php echo htmlspecialchars($license['li_value']); ?></span>
										</div>
									</label>
								<?php endforeach; ?>
							</div>

							<input type="hidden" name="rep_url" value="<?= $report['rep_url'] ?>">

							<input type="hidden" name="report_id" value="<?= $report['rep_id'] ?>">
							<input type="hidden" name="sc1_name" value="<?= esc($category['sc1_name']); ?>">
							<input type="hidden" name="rep_page" value="<?= $report['rep_page'] ?>">
							<input type="hidden" name="rep_title" value="<?= $report['rep_title'] ?>">

							<input type="hidden" name="rep_date" value="<?= $report['rep_date'] ?>">
                        
							<button type="submit" name="submit_todo" value="buy_now" class="licen-btn">
								<i class="fa fa-credit-card" aria-hidden="true"></i>buy now
							</button>
							<button type="submit" name="submit_todo" value="add_to_cart" class="licen-btn">
								<i class="fa fa-cart-plus" aria-hidden="true"></i>add to cart
							</button>

						</div>
					</form>
				</div>
				<!-- disply report Licenses End -->





				<!-- similar Report Disply start -->
				<div class="sim-rep">
					<h3 class="title">Similar Reports</h3>
					<ul>
						<?php foreach ($similarReports as $similarReport) : ?>
							<li>
								<a href="<?= base_url('report/' . $similarReport['rep_id'] . '/' . urlencode($similarReport['rep_url'])) ?>">
									<h4><?= esc($similarReport['rep_title']) ?></h4>
								</a>
								<p class="trim-line"><?= esc($similarReport['rep_descrip']) ?></p>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>

				<!-- similar Report Disply End -->


			</div>

		</div>
	</div>





	<!-- Include footer.php -->
	<?php include('footer.php'); ?>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" ></script> -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


	</body>

</html>