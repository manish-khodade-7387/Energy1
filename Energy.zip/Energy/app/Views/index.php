<!DOCTYPE html>
<html lang="en">

<head>
	<title>Energy</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

	<style>
       .linktag{
    font-size: 17px !important;
    padding: 10px 10px 4px 80px !important;
    background-color: #e3b04b !important;
}
    </style>
</head>

<!-- Include header.php -->
<?php include('header.php'); ?>










<div class="banner">
<div class="container">


	<div class="row">
		<div class="col-md-12 text-center">
			<h1>Global Market Research Reports Over 1 Million<br>Topics of various sectors</h1>
			<a href="<?=base_url()?>letest-reports" class="btn-2">Latest Reports <i class="fa fa-angle-right"></i></a>
		</div>
		
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<div class="banner-catg">
				<h2>Search by report category</h2>
				<ul>
				<?php foreach ($categories as $category): ?>

					<li><a href="<?= base_url('category/' . $category['sc1_url']) ?>">
						<span class="cate-icon metallic"></span><?= $category['sc1_name']; ?>
					</a></li>
					<?php endforeach; ?>

				</ul>
			</div>
		</div>
	</div>



</div>
</div>

<section>
<div class="container">
<div class="row">

	<div class="col-md-12 text-center">
		<h2 class="head-1">About <span>24Market Reports</span></h2>
	</div>	
	<div class="clearfix"></div>
	
	<div class="col-lg-10 col-md-12  about-index">
	<div class="about-img">
		<p>24chemical has a targeted view to provide business insights and consulting to assist its clients to make strategic business decisions and achieve sustainable growth in their respective market domain.</p>
	</div>
	<?php 
if ($aboutUs) {
    $content = $aboutUs['cms_content'];
    $phrase = "specific markets.";
    $limit = 3; // limit to stop printing after encountering the phrase three times
    $occurrences = 0;

    while (($pos = strpos($content, $phrase)) !== false && $occurrences < $limit) {
        echo substr($content, 0, $pos + strlen($phrase));
        $content = substr($content, $pos + strlen($phrase));
        $occurrences++;
    }
}
?>

	<a href="<?=base_url()?>about-Us" class="btn-1 pull-right">Read more &nbsp;&nbsp;<i class="fa fa-arrow-circle-o-right"></i></a>
	</div>
	

</div>
</div>
</section>



<section class="news-sec">
<div class="container">
<div class="row">
	
		<div class="col-md-12">
			<div class="head-2">
				<h2 class="title">Latest<span> News</span></h2>
			</div>
		</div>
		
		<div class="clearfix"></div>
		
		<?php foreach ($news as $article): ?>

		<div class="col-md-3">
			<div class="inews-list">
			<a href="<?= base_url('blog/'.$article['id'].'/'.$article['nws_url']) ?>">
			
				<div class="news-img">
					<img src="assets/images/Antibiotics.jpg" alt="news image" title="news title"/>
				</div>
				
				<!-- <div class="news-img"> -->
                <!-- <img src="<?php echo base_url('assets/images/'.$article['nws_featured_image']); ?>" alt="news image" title="news title"/> -->
                    <!-- </div> -->


				<div class="title">
					<p><?= $article['nws_date']; ?></p>
					<h4><?= $article['nws_title']; ?></h4>
				</div>

				
			</a>
			</div>
		</div>
		<?php endforeach; ?>
		
		
		
		<div class="col-md-12">
			<a href="<?=base_url()?>blog" class="btn-1 pull-right">View all &nbsp;&nbsp;<i class="fa fa-arrow-circle-o-right"></i></a>
		</div>
	
</div>
</div>
</section>


<section>
<div class="container">
<div class="row">

	<div class="col-md-8">
		<div class="head-2">
			<h2 class="title">Latest<span> Reports</span></h2>
		</div>
		
		<?php foreach ($firstThreeReportsData as $report): ?>
    <div class="col-md-12 report-list">			
        <img src="https://www.24marketreports.com/assets/images/covers/life-sciences/Life-Sciences-2.jpg" alt="report image" title="report tile"/>			
        <p class="date"><?= $report['rep_date']; ?></p>
        <h4><a href="<?= base_url('report/' . $report['rep_id'] . '/' . urlencode($report['rep_url'])) ?>"><?= $report['rep_title']; ?></a></h4>
        <p>Pages: <?= $report['rep_page']; ?> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; Report Code: <?= $report['rep_id']; ?>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
        <a href="<?= base_url('report/' . $report['rep_id'] . '/' . urlencode($report['rep_url'])) ?>"><strong>Read more</strong></a></p>
    </div>
<?php endforeach; ?>


			
			
			<a href="<?=base_url()?>letest-reports" class="btn-1 pull-right">View all &nbsp;&nbsp;<i class="fa fa-arrow-circle-o-right"></i></a>
		
		
	</div>
	
	
	
	<div class="col-md-4">
		<div class="key-point">
			<h5>OUR KEY POINTS</h5>
			<ul class="key-list">
				<li>
				<i class="fa fa-search-plus"></i>
				<h4>Comprehensive Research</h4>
				<p>Offers Penetrative insights &amp; holistic understanding of the market</p>
				</li>
				
				<li>
				<i class="fa fa-database"></i>
				<h4>Data Accuracy & Reliability</h4>
				<p>Strictly follows the Research Methodology for flawless results</p>
				</li>
				<li>
				<i class="fa fa-money"></i>
				<h4>Competitive Pricing</h4>
				<p>Ensure the best and affordable pricing</p>
				</li>
				<li>
				<i class="fa fa-shield"></i>
				<h4>Security & Confidentiality</h4>
				<p>All your transactions are secured end-to-end, ensuring a satisfactory purchase</p>
				</li>
			</ul>
		</div>
	</div>

</div>
</div>
</section>








<!-- Include the footer -->
<?php include('footer.php'); ?>





<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	 -->
<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function(){
  $("#search_icon").click(function(){
    $("#search_bar").slideToggle();
  });
});
</script>
</body>
</html>