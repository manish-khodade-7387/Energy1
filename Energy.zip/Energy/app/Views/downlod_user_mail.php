<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Report Download Request</title>
</head>
<body>
    <h1>Thank you for requesting to download a report</h1>
    <p>Here are the details of your request:</p>
    <table>
        <tr>
            <th>Report Title</th>
            <td><?= esc($contact_rep_title) ?></td>
        </tr>
        <tr>
            <th>Report Date</th>
            <td><?= esc($contact_rep_date) ?></td>
        </tr>
        <tr>
            <th>Contact Person</th>
            <td><?= esc($contact_person) ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?= esc($contact_email) ?></td>
        </tr>
        <tr>
            <th>Phone</th>
            <td><?= esc($contact_phone) ?></td>
        </tr>
        <tr>
            <th>Company</th>
            <td><?= esc($contact_company) ?></td>
        </tr>
        <tr>
            <th>Job Role</th>
            <td><?= esc($contact_job_role) ?></td>
        </tr>
        <tr>
            <th>Report URL</th>
            <td><?= esc($contact_report_url) ?></td>
        </tr>
        <tr>
            <th>Contact Code</th>
            <td><?= esc($contact_code) ?></td>
        </tr>
        <tr>
            <th>Date and Time</th>
            <td><?= esc($contact_datetime) ?></td>
        </tr>
    </table>
</body>
</html>
