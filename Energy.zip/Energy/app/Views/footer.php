<?php
$start = microtime(true); // Record the start time
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>footer</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css">
</head>
<style>
    .call_to_action {
        background-image: linear-gradient(319deg, #ba2d0b -15%, #fe7f2d 37%, #ffbf46 80%) !important;
        color: #fff;
        padding: 35px 0 35px;
    }
    a {
        text-decoration: none;
    }
    @media only screen and (min-width: 720px)and (max-width:920px) {
        .rd-tab {
            display: flex;
        }
        .search_box {
            width: 350px;
        }
        .link_follow ul li a {
            width: 30px;
            height: 30px;
            line-height: 30px;
            font-size: 15px;
        }
        .call_text h3 {
            font-size: 20px;
        }
        .discover_now a {
            text-align: center;
            font-size: 12px;
            width: 120px;
            padding: 0px;
        }
    }
</style>

<body>
    <section class="call_to_action">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="call_action_inner">
                        <div class="call_text">
                            <h3>We Have <span>Recommendations</span> for You</h3>
                            <p>Take 30% off when you spend $150 or more with code Autima11</p>
                        </div>
                        <div class="discover_now">
                            <a href="<?= base_url() ?>letest-reports">discover now</a>
                        </div>
                        <div class="link_follow">
                            <ul>
                                <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="#"><i class="fa-brands fa-google"></i></a></li>
                                <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer_widgets">
        <div class="container">
            <div class="footer_top">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-xs-12">
                        <div class="widgets_container contact_us">
                            <div class="footer_logo">
                                <a href="<?= base_url() ?>"><img src="<?= base_url() ?>assets/images/logo-new.png" alt=""></a>
                            </div>
                            <div class="footer_contact">
                                <p>We are a team of designers and developers that<br>
                                    create high quality Magento, Prestashop, Opencart...</p>
                                <p><span>Address</span> 4710-4890 Breckinridge St, UK Burlington, VT 05401</p>
                                <p>
                                    <span>Need Help?</span>
                                    Call: <a href="tel:1-800-345-6789"><?= $contactInfo['info_virtual_no'] ?></a><br>
                                    Email: <a href="mailto:<?= $contactInfo['info_mail'] ?>"><?= $contactInfo['info_mail'] ?></a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6 col-xs-6">
                        <div class="widgets_container widget_menu">
                            <h3>Information</h3>
                            <div class="footer_menu">
                                <ul>
                                    <?php foreach ($cmsTitles as $cmsTitle) : ?>
                                        <li><a href="<?= base_url(strtolower(url_title($cmsTitle['cms_title'], '-', true))) ?>"><?= esc($cmsTitle['cms_title']) ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-xs-12">
                        <div class="widgets_container">
                            <h3>Newsletter Subscribe</h3>
                            <p>We’ll never share your email address with a third-party.</p>
                            <div class="subscribe_form">
                                <form id="mc-form" class="mc-form footer-newsletter" action="<?= base_url('subscribe') ?>" method="post" novalidate="true">
                                    <input id="mc-email" type="email" autocomplete="off" placeholder="Enter you email address here..." name="EMAIL" required>

                                    <button id="mc-submit" type="button">Subscribe</button>
                                            <!-- Error message displayed above the Subscribe button -->
        <div id="subscribe-error-message" class="text-danger" style="display: none;">Please enter a valid email address.</div>

                                </form>
                                <?php
                                // Calculate the load time
                                $end = microtime(true);
                                $loadTime = round(($end - $start), 4);
                                ?>
                                <footer>Page loaded in <?php echo $loadTime; ?> seconds.</footer>
                                <!-- mailchimp-alerts Start -->
                                <div class="mailchimp-alerts text-centre">
                                    <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                    <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                    <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                                </div><!-- mailchimp-alerts end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer_bottom">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="copyright_area">
                            <p>© All Rights Reserved, 24 Chemical Research</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="footer_payment text-right">
                            <a href="#"><img src="https://www.24chemicalresearch.com/assets/images/payment-image2.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap Modal for validation errors -->
    <div class="modal fade" id="validationModal" tabindex="-1" aria-labelledby="validationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="validationModalLabel">Validation Error</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body">
                    Please enter a valid email address.
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>    -->
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#mc-submit').on('click', function(event) {
                var email = $('#mc-email').val();
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
                if (email === '' || !emailPattern.test(email)) {
                    event.preventDefault();
                    $('#error-message').hide(); // Hide any existing error messages
                    $('#subscribe-error-message').show(); // Show the error message above the Subscribe button
                } else {
                    $('#mc-form').submit();
                }
            });
        });
    </script>
</body>

</html>
