<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You for Your Search</title>
</head>
<body>
    <h2>Thank You for Your Search</h2>
    <p>Hello <?= $full_name ?>,</p>
    <p>We have received your search request with the following details:</p>
    <ul>
        <li><strong>Topic:</strong> <?= $topic ?></li>
        <li><strong>Full Name:</strong> <?= $full_name ?></li>
        <li><strong>Email:</strong> <?= $email_id ?></li>
        <li><strong>Message:</strong> <?= $message ?></li>
    </ul>
    <p>We will get back to you soon.</p>
    <p>Thank you.</p>
</body>
</html>
