<!DOCTYPE html>
<html lang="en">

<head>
    <title>SAMPLE REPORTS</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/new.css">

    <style>
        .form1 {
            padding: 1.375rem .75rem !important;
        }

        .error-message {
            color: red;
            font-size: 0.9em;
            margin-top: 0.2em;
        }
    </style>
    <?php include('header.php'); ?>
</head>

<body>
    <div class="col-md-12">
        <ol class="breadcrumb linktag">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('report/' . $report['rep_id'] . '/' . urlencode($report['rep_url'])) ?>"><?= esc($report['rep_title']); ?></a></li>
            <li class="breadcrumb-item active">Sample</li>
        </ol>
    </div>

    <!-- SAMPLE REPORT STARTS HERE -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head-2">
                    <h1 class="title"><span>Sample Report</span></h1>
                </div>
            </div>
        </div>
    </div>

    <div class="">
        <div class="wrapper">
            <div class="innerFirst">
                <div class="">
                    <div class="row heading-div">
                        <div class="col-md-3 rd-cover">
                            <img src="https://www.24chemicalresearch.com/assets/images/covers/inorganic-materials/Inorganic-Material.jpg" alt="report cover" style="width:120px;">
                        </div>
                        <div class="col-md-8">
                            <h2 class="head-3"><?= esc($report['rep_title']); ?></h2>
                            <p class="text-muted">Published on: <strong><?= esc($report['rep_date']); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;Pages: <strong><?= esc($report['rep_page']); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;Report Code: <strong><?= esc($report['rep_id']); ?></strong></p><br>
                        </div>
                    </div>
                </div>
                <p class="back-btn"><a href="<?= base_url('report/' . $report['rep_id'] . '/' . urlencode($report['rep_url'])) ?>"><strong><i class="fa fa-angle-double-left"></i>&nbsp;&nbsp;</strong></a></p>

                <div class="inner">
                    <div class="image-holder">
                        <img class="img-img" src="<?= base_url('./assets/images/Metallic-Material.jpg') ?>" alt="image">
                    </div>

                    <form action="<?= base_url('save') ?>" method="post" id="checkoutForm">
                        <input type="hidden" name="rep_title" value="<?= esc($report['rep_title']); ?>">
                        <input type="hidden" name="rep_date" value="<?= esc($report['rep_date']); ?>">
                        <input type="hidden" name="rep_page" value="<?= esc($report['rep_page']); ?>">
                        <input type="hidden" name="rep_id" value="<?= esc($report['rep_id']); ?>">
                        <input type="hidden" name="report_url" value="<?= current_url(); ?>">

                        <div class="flexit has-feedback newform-group">
                            <label class="control-label lable-file col-sm-4" for="format">File Format *:</label>
                            <div class="col-sm-8 radio-btn">
                                <label class="radio-inline"><input type="radio" name="format" value="PDF" checked=""><i class="fa fa-file-pdf-o"> &nbsp;&nbsp;</i>PDF</label>
                                <label class="radio-inline"><input type="radio" name="format" value="PPT"><i class="fa fa-file-powerpoint-o"> &nbsp;&nbsp;</i>PPT</label>
                            </div>
                        </div>
                        <div class="name-div">
                        <div class="form-group">
                            <input type="text" placeholder="First Name" name="first_Name" class="form-control form1" required>
                            <div class="error-message" id="firstNameError"></div>
                        </div>
                        <div class="form-group">
                            <input type="text" placeholder="Last Name" name="last_name" class="form-control form1" required>
                            <div class="error-message" id="lastNameError"></div>
                        </div>
                        </div>
                        <div class="form-wrapper">
                            <input type="text" placeholder="Company Name" name="company" class="form-control font-input form1" required>
                            <div class="error-message" id="companyError"></div>
                        </div>
                        <div class="form-wrapper">
                            <input type="email" placeholder="Business Email Address" name="email" class="form-control font-input form1" required>
                            <div class="error-message" id="emailError"></div>
                        </div>
                        <div class="form-wrapper">
                            <input type="text" placeholder="Contact Number" name="phone" class="form-control font-input form1" required>
                            <div class="error-message" id="phoneError"></div>
                        </div>
                        <div class="form-wrapper">
                            <input type="text" placeholder="Job Role" name="job_role" class="form-control font-input form1" required>
                            <div class="error-message" id="jobRoleError"></div>
                        </div>
                        <div class="form-wrapper">
                            <div class="input-group">
                                <input type="text" placeholder="Enter Security code" name="code" class="form-control font-input form1" required>
                            </div>
                            <span id="code"><?= $securityCode ?></span>
                            <div class="error-message" id="codeError"></div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="submit-btn">Submit to Download Sample Report</button>
                            <br><br>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Include the footer -->
    <?php include('footer.php'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXtmVPfN5aJJ0VQmLN5FYEVvbh4VRhpr9h4G" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function () {
            $('#checkoutForm').on('submit', function (event) {
                var isValid = true;

                // Clear previous error messages
                $('.error-message').text('');

                // Validate first name
                var firstName = $('input[name="first_Name"]').val();
                if (firstName === '') {
                    isValid = false;
                    $('#firstNameError').text("First name is required.");
                }

                // Validate last name
                var lastName = $('input[name="last_name"]').val();
                if (lastName === '') {
                    isValid = false;
                    $('#lastNameError').text("Last name is required.");
                }

                // Validate email
                var email = $('input[name="email"]').val();
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
                if (email === '' || !emailPattern.test(email)) {
                    isValid = false;
                    $('#emailError').text("Please enter a valid email address.");
                }

                // Validate company name
                var companyName = $('input[name="company"]').val();
                if (companyName === '') {
                    isValid = false;
                    $('#companyError').text("Company name is required.");
                }

                // Validate phone number (6 to 15 digits)
                var phone = $('input[name="phone"]').val();
                var phonePattern = /^\d{6,15}$/;
                if (phone === '' || !phonePattern.test(phone)) {
                    isValid = false;
                    $('#phoneError').text("Please enter a valid phone number between 6 to 15 digits.");
                }

                // Validate job role
                var jobRole = $('input[name="job_role"]').val();
                if (jobRole === '') {
                    isValid = false;
                    $('#jobRoleError').text("Job role is required.");
                }

                // Validate security code
                var securityCode = $('input[name="code"]').val();
                var actualCode = $('#code').text().trim();
                if (securityCode === '' || securityCode !== actualCode) {
                    isValid = false;
                    $('#codeError').text("Security code does not match.");
                }

                // If any validation fails, prevent form submission
                if (!isValid) {
                    event.preventDefault();
                }
            });
        });
    </script>
</body>

</html>
