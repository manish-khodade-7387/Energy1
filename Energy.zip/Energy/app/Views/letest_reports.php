<?php
// Get the current page from URL parameters, default to 1 if not set
$page = isset($_GET['page']) ? $_GET['page'] : 1;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Latest Reports</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <style>
       .linktag{
    font-size: 17px !important;
    padding: 10px 10px 4px 80px !important;
    background-color: #e3b04b !important;
}
    </style>
</head>

<body>

    <!-- Include header.php -->
    <?php include('header.php'); ?>
    
    <div class="col-md-12">
	<ol class="breadcrumb linktag">
		<li class="breadcrumb-item"><a href="<?=base_url()?>">Home</a></li>
		<li class="breadcrumb-item">Latest Reports</li>
	</ol>
	</div>
    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="head-2">

                    <h1 class="title">Latest<span> Reports</span></h1>

                </div>

            </div>

            <div class="clearfix"></div>

            <div class="col-md-12">

                <div class="sort-by">
                    <div class="page-no">
                        <strong></strong>
                    </div>

                    <div class="sort-opt">

                        <form method="get" action="" name="filters">

                            <strong class="title">Sort By</strong>

                            <div class="input-group sort-input">
                                <span class="input-group-addon"><i class="fa fa-list-ul"></i></span>
                                <select class="selectClass" id="filtercat" name="filtercat" data-fv-field="filtercat">

                                    <option value="">Category</option>
                                    <?php foreach ($categories as $category) : ?>
                                        <option value="<?= $category['sc1_id'] ?>"><?= $category['sc1_name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="input-group sort-input">
                                <span class="input-group-addon"><i class="fa fa-sort"></i></span>
                                <select class="selectClass" id="filterordby" name="ordby" data-fv-field="filterordby">
                                    <option value="">Order By</option>

                                    <option value="title_asc">Title Asc</option>

                                    <option value="title_desc">Title Desc</option>

                                    <option value="date_asc">Date Asc</option>

                                    <option value="date_desc">Date Desc</option>
                                </select>
                            </div>

                        </form>

                    </div>

                </div>

            </div>

            <!-- report list start -->
            <div id="reportList">
            </div>
            <!-- report list start end -->

            <div id="pagination"></div>

        </div>




    </div>

    </div>

    <!-- Include the footer -->
    <?php include('footer.php'); ?>



    <script>
        $(document).ready(function() {
            // Initial page load
            loadReports(<?php echo $page; ?>);

            // Function to load reports via AJAX
            function loadReports(page) {
                var orderBy = $('#filterordby').val(); // Get selected sorting option
                var categoryId = $('#filtercat').val(); // Get selected category ID
                $.ajax({
                    url: '<?= base_url('letestreport/loadReports') ?>/' + page,
                    type: 'GET',
                    data: {
                        orderBy: orderBy,
                        categoryId: categoryId
                    }, // Send sorting option and category ID to the server
                    dataType: 'json',
                    success: function(response) {
                        // Append loaded reports to the existing list
                        $('#reportList').empty();
                        $.each(response.reports, function(index, report) {
                            var listItem = `
                            <div class="col-md-12 report-list latest">
                                <p class="date">${report.rep_date}</p>
                                <img alt="" class="report-cover" src="<?= base_url() ?>./assets/images/Speciality-Chemical.jpg" title="report tile">
                                <h4><a href="<?= base_url() ?>/report/${report.rep_id}/${encodeURIComponent(report.rep_url)}">${report.rep_title}</a></h4>
                                <p>Pages: ${report.rep_page} &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; Report Code: ${report.rep_id}&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                                    <a href="<?= base_url() ?>/report/${report.rep_id}/${encodeURIComponent(report.rep_url)}"><strong class="read">Read more</strong></a>
                                </p>
                            </div>`;
                            // Append the generated report HTML to the reportList div
                            $('#reportList').append(listItem);
                        });

                        $('#reportList').css({
                            'display': 'contents'
                        });

                        // Generate pagination
                        generatePagination(page, response.totalReports, response.perPage);
                        // Update URL with page number
                        history.pushState(null, null, '<?= base_url('letest-reports') ?>?page=' + page);
                    }
                });
            }


            // Function to generate pagination
            function generatePagination(currentPage, totalItems, itemsPerPage) {
                $('#pagination').empty();
                var totalPages = Math.ceil(totalItems / itemsPerPage);

                // Update the page number in the page-no div
                $('.page-no strong').text('Page ' + currentPage + ' of ' + totalPages);

                // Create the pagination HTML structure
                var paginationHTML = '<div class="col-md-12"><div class="sort-by"><div class="page-no"><strong>Page ' + currentPage + ' of ' + totalPages + '</strong></div><div class="sort-opt"><ul class="pagination cust-pagination" style="margin: 0;float:left;">';

                // Add the pagination links
                paginationHTML += '<li><a class="pageClass" href="#" data-page="1">1</a></li>'; // First page
                paginationHTML += '<li><a class="pageClass" href="#" data-page="2">2</a></li>'; // Second page
                paginationHTML += '<li><a class="pageClass" href="#" data-page="3">3</a></li>'; // Third page

                // Add next and last page links
                if (currentPage < totalPages) {
                    paginationHTML += '<li rel="next"><a href="#" data-page="' + (currentPage + 1) + '" rel="next">»</a></li>'; // Next page
                    paginationHTML += '<li><a href="#" data-page="' + totalPages + '">Last</a></li>'; // Last page
                }
                if (currentPage > 1) {
                    paginationHTML += '<li><a href="#" data-page="' + (currentPage - 1) + '">Previous</a></li>'; // Previous page
                }

                paginationHTML += '</ul></div></div></div>';

                // Append the pagination HTML to the pagination container
                $('#pagination').append(paginationHTML);

                // Pagination link click event
                $('#pagination').on('click', 'a.pageClass', function(e) {
                    e.preventDefault();
                    var page = $(this).data('page');
                    loadReports(page);
                });

                // Previous page link click event
                $('#pagination').on('click', 'a[data-page="' + (currentPage - 1) + '"]', function(e) {
                    e.preventDefault();
                    var page = $(this).data('page');
                    loadReports(page);
                });

                // Next page link click event
                $('#pagination').on('click', 'a[data-page="' + (currentPage + 1) + '"]', function(e) {
                    e.preventDefault();
                    var page = $(this).data('page');
                    loadReports(page);
                });

                // Last page link click event
                $('#pagination').on('click', 'a[data-page="' + totalPages + '"]', function(e) {
                    e.preventDefault();
                    var page = $(this).data('page');
                    loadReports(page);
                });
            }



            // Event listener for sorting option change
            $('#filterordby, #filtercat').on('change', function() {
                loadReports(1); // Reload reports when sorting option or category changes
            });

            // Event listener for pagination link click
            $('#pagination').on('click', 'a.pageClass', function(e) {
                e.preventDefault();
                var page = $(this).data('page');
                loadReports(page);
            });

        });
    </script>

</body>

</html>