<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Subscription Email</title>
</head>
<body>
    



    <h2>New Subscription Received</h2>
    <p>A new user has subscribed to the newsletter:</p>
    <p>Email: <?= $email ?></p>
    <p>Thank you.</p>

</body>
</html>
