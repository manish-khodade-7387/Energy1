
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Error</title>

  <style>
       .linktag{
    font-size: 17px !important;
    padding: 10px 10px 4px 80px !important;
    background-color: #e3b04b !important;
}
    </style>
</head>
<?php include('header.php'); ?>

<div class="col-md-12">
	<ol class="breadcrumb linktag">
		<li class="breadcrumb-item"><a href="<?=base_url()?>">Home</a></li>
		<li class="breadcrumb-item"><a href="#">hsgvgksduhuhdv</a></li>
		<li class="breadcrumb-item active">vbgiuveuiv</li>
	</ol>
	</div>

  
  <div id="error-page">
    <div class="content">
      <h2 class="header" data-text="404">
        404
      </h2>
      <h4 data-text="Opps! Page not found">
        Opps! Page not found
      </h4>
      <p>
        Sorry, the page you're looking for doesn't exist. If you think something is broken, report a problem.
      </p>
      <div class="btns">
        <a href="<?=base_url()?>">return home</a>
        <a href="<?=base_url()?>letest-reports"> LATEST REPORTS </a>
      </div>
    </div>
  </div>





<!-- Include the footer -->
<?php include('footer.php'); ?>




